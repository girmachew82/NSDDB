@2023
<?php /**PATH F:\dbu\resources\views/layout/footer.blade.php ENDPATH**/ ?>