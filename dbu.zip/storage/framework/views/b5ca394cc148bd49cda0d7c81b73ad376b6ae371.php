<?php $__env->startSection('content'); ?>
<div style="height: 100cm; border:1px solid red; border-radius:5px;">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\dbu\resources\views/welcome.blade.php ENDPATH**/ ?>