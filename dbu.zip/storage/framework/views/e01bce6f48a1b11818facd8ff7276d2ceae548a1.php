<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>DBU</title>

        <!-- Fonts -->

    </head>
    <body class="antialiased">
        <?php echo e(View::make('layout.top')); ?>

        <?php echo e(View::make('layout.navigation')); ?>

        <?php echo $__env->yieldContent('content'); ?>
        <?php echo e(View::make('layout.footer')); ?>

    </body>
</html>
<?php /**PATH F:\dbu\resources\views/app.blade.php ENDPATH**/ ?>