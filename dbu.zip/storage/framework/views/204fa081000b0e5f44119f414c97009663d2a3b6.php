<style>
    .news{
        border: 1px solid rgb(17, 85, 210);
        border-radius: 5px;
        margin: 5px;
    }
    .pagination {
  list-style: none;
  padding-left: 0;
  text-align: center;
}

.pagination li {
  display: inline-block;
}

.pagination li+li {
  margin-left: 1rem;
}

.pagination a {
  text-decoration: none;
  padding: 0.2rem 0.4rem;
  color: rgb(0, 0, 50);
  border: 1px solid rgb(22, 113, 211);
  border-radius: 20px;
}
.pagination a.active {
  background-color: #4CAF50;
  color: white;
}
</style>


<?php $__env->startSection('content'); ?>
<center>
  <strong>Latest news</strong>
</center>

<br>
<div class="row">
<div>
<marquee behavior="" direction="">
<?php $__currentLoopData = $latestnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lnws): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <img src="images/news/<?php echo e($lnws['photo']); ?>" width="50" height="50" style="border-radius: 50%" alt="">
<?php echo e($lnws['title']); ?>

<?php echo e($lnws['description']); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</marquee>
</div>
<div>
   <!-- The form -->
<form class="example" action="action_page.php">
    <input type="text" placeholder="Search.." name="search">
  </form>
</div>
</div>
<?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nws): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="news">
    <?php echo e($nws['title']); ?><br>
    <img src="images/news/<?php echo e($nws['photo']); ?>" width="100" height="100" style="border-radius: 50%" alt="">
    <?php echo e($nws['description']); ?><br>
    <?php echo $nws['detail']; ?><br>
    <?php echo e($nws['post_date']); ?>


</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
No data found
<?php endif; ?>
<div class="pgn">
 <?php echo e($news->links()); ?>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\dbu\resources\views/news.blade.php ENDPATH**/ ?>