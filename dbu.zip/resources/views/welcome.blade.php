
@extends('app')
@section('content')
<div style="height: 100cm; border:1px solid red; border-radius:5px;">

</div>
@endsection
