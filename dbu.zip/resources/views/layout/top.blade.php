<style>
    body{
        border: 0;
        margin: 0;
    }
    .container{
        background-color:rgb(255,191,0);
        color:rgb(255, 255, 255);
        border-top: 0px;
        height: 50px;
        border-radius: 5px;
    }
</style>
<div class="container">
Debre Berhan

</div>
